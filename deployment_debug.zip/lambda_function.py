"""
TUUN AI Chat Lambda Function (改善版 v2.0)
パーソナルドクター/トレーナー形式のAIチャット

主な改善点:
- 初回のみ血液データを送信（プロンプト短縮）
- 遺伝子データは会話中にAIが必要な項目を要求
- インタビュー形式で情報収集
- フレンドリーで詳細な応答
"""

print("=" * 80)
print("[INIT] lambda_function.py initialization started")
print("=" * 80)

print("[IMPORT] json...")
import json
print("  ✅ json")

print("[IMPORT] boto3...")
import boto3
print("  ✅ boto3")

print("[IMPORT] os...")
import os
print("  ✅ os")

print("[IMPORT] datetime...")
from datetime import datetime
print("  ✅ datetime")

print("[IMPORT] typing...")
from typing import Dict, List, Optional, Any
print("  ✅ typing")

print("[IMPORT] openai...")
try:
    import openai
    print(f"  ✅ openai (version: {openai.__version__})")
except ImportError as e:
    print(f"  ❌ Failed to import openai: {e}")
    raise

print("[INIT] Creating Secrets Manager client...")
secretsmanager = boto3.client('secretsmanager', region_name='ap-northeast-1')
print("  ✅ Secrets Manager client created")

print("[INIT] Initialization complete")
print("=" * 80)

# OpenAI API Keyを取得
def get_openai_api_key():
    """Secrets ManagerからOpenAI API Keyを取得"""
    try:
        secret_name = "tuunapp/openai-api-key"
        response = secretsmanager.get_secret_value(SecretId=secret_name)
        secret = json.loads(response['SecretString'])
        return secret['api_key']
    except Exception as e:
        print(f"❌ [ERROR] Failed to get OpenAI API key: {str(e)}")
        raise


def lambda_handler(event, context):
    """Lambda メインハンドラー"""
    try:
        print("\n" + "=" * 80)
        print("[HANDLER] Request received")
        print("=" * 80)

        # API Keyを設定（Secrets Managerから取得）
        print("[AUTH] Configuring OpenAI API key...")
        try:
            openai.api_key = get_openai_api_key()
            print("  ✅ API key configured from Secrets Manager")
        except Exception as e:
            print(f"  ❌ Failed to get API key: {e}")
            raise

        print(f"[REQUEST] Event: {json.dumps(event, ensure_ascii=False)[:200]}...")

        # リクエストボディを解析
        print("[PARSE] Parsing request body...")
        body = json.loads(event.get('body', '{}'))

        user_id = body.get('userId')
        message = body.get('message')
        topic = body.get('topic', 'general_health')
        is_first_message = body.get('isFirstMessage', False)

        # 会話履歴を取得
        conversation_history = body.get('conversationHistory', [])

        # 血液データを取得（初回のみ）
        blood_data = body.get('bloodData', None)

        # 遺伝子データを取得（AIが要求した場合のみ）
        gene_data = body.get('geneData', None)

        # 利用可能な遺伝子カテゴリーリスト（初回のみ）
        available_gene_categories = body.get('availableGeneCategories', [])

        print(f"  ✅ userId: {user_id}")
        print(f"  ✅ message: {len(message) if message else 0} chars")
        print(f"  ✅ topic: {topic}")
        print(f"  ✅ isFirstMessage: {is_first_message}")
        print(f"  ✅ conversationHistory: {len(conversation_history)} messages")
        if blood_data:
            print(f"  ✅ bloodData: {len(blood_data)} items")
        if gene_data:
            print(f"  ✅ geneData: {len(gene_data)} categories")
        if available_gene_categories:
            print(f"  ✅ availableGeneCategories: {len(available_gene_categories)} categories")

        if not user_id or not message:
            print("  ❌ Validation failed: userId or message missing")
            return {
                'statusCode': 400,
                'headers': cors_headers(),
                'body': json.dumps({
                    'error': 'userId and message are required',
                    'errorCode': 'INVALID_REQUEST'
                })
            }

        # プロンプトを構築
        print("[BUILD] Building chat messages...")
        messages = build_chat_messages(
            user_message=message,
            conversation_history=conversation_history,
            blood_data=blood_data,
            gene_data=gene_data,
            available_gene_categories=available_gene_categories,
            is_first_message=is_first_message
        )
        print(f"  ✅ Built {len(messages)} messages")
        for i, msg in enumerate(messages):
            print(f"    {i+1}. {msg['role']}: {len(msg['content'])} chars")

        # OpenAI APIを呼び出し
        print("[OPENAI] Calling OpenAI API...")
        response = call_openai(messages)
        print(f"  ✅ Response received: {len(response)} chars")

        print("[HANDLER] Request completed successfully")
        print("=" * 80 + "\n")

        return {
            'statusCode': 200,
            'headers': cors_headers(),
            'body': json.dumps({
                'response': response,
                'timestamp': datetime.now().isoformat(),
                'disclaimer': 'この情報は参考情報です。医療的な判断は医師にご相談ください。'
            }, ensure_ascii=False)
        }

    except Exception as e:
        print(f"❌ [ERROR] Exception in lambda_handler: {str(e)}")
        import traceback
        traceback.print_exc()

        return {
            'statusCode': 500,
            'headers': cors_headers(),
            'body': json.dumps({
                'error': 'Internal server error',
                'errorCode': 'INTERNAL_ERROR',
                'details': str(e)
            })
        }


def build_chat_messages(
    user_message: str,
    conversation_history: List[Dict],
    blood_data: Optional[List[Dict]],
    gene_data: Optional[Dict],
    available_gene_categories: List[str],
    is_first_message: bool
) -> List[Dict]:
    """チャットメッセージを構築"""

    messages = []

    # システムプロンプト（ペルソナ定義）
    system_prompt = build_system_prompt()
    messages.append({
        "role": "system",
        "content": system_prompt
    })

    # 初回メッセージの場合、血液データと遺伝子カテゴリーリストを含める
    if is_first_message:
        context_message = build_initial_context(blood_data, available_gene_categories)
        messages.append({
            "role": "system",
            "content": context_message
        })

    # 会話履歴を追加
    for msg in conversation_history[:-1]:  # 最新のユーザーメッセージは除く
        messages.append({
            "role": msg.get("role"),
            "content": msg.get("content")
        })

    # 遺伝子データが提供された場合、システムメッセージとして追加
    if gene_data:
        gene_context = build_gene_data_context(gene_data)
        messages.append({
            "role": "system",
            "content": gene_context
        })

    # ユーザーメッセージを追加
    messages.append({
        "role": "user",
        "content": user_message
    })

    return messages


def build_system_prompt() -> str:
    """システムプロンプト（ペルソナ定義）"""
    return """あなたは、TUUN専属のパーソナルヘルスアドバイザーです。
医師とパーソナルトレーナーの知識を兼ね備え、ユーザーの健康を総合的にサポートします。

【あなたの役割】
1. ユーザーの血液検査データと遺伝子情報を統合分析
2. インタビュー形式で必要な情報を聞き出す
3. 科学的根拠に基づいた具体的なアドバイスを提供
4. フレンドリーで親しみやすい口調で応答

【応答スタイル】
- 絵文字を適度に使用（🧬 🩸 ✅ ❌ 💪 など）
- 専門用語は使うが、必ず分かりやすく説明
- 具体的な数値や行動プランを提示
- ユーザーを励まし、実践可能な提案をする

【重要な制約】
- 医療診断は行わない（あくまで健康アドバイス）
- 不明な点は正直に「わからない」と伝える
- 深刻な異常値がある場合は医師の受診を勧める

【遺伝子データの要求方法】
必要な遺伝子情報がある場合は、以下のフォーマットで要求してください：
🧬 [カテゴリー名]に関する遺伝子情報

例：
🧬 脂質代謝に関する遺伝子情報
🧬 インスリン感受性に関する遺伝子情報

利用可能なカテゴリーは初回メッセージで提供されます。"""


def build_initial_context(blood_data: Optional[List[Dict]], available_gene_categories: List[str]) -> str:
    """初回メッセージのコンテキスト（血液データ + 遺伝子カテゴリーリスト）"""
    context_parts = []

    # 血液データ
    if blood_data:
        context_parts.append("【ユーザーの血液検査結果】")

        normal_items = []
        attention_items = []
        abnormal_items = []

        for item in blood_data:
            status = item.get('status', '').lower()
            item_text = f"- {item.get('nameJp', item.get('key'))}: {item.get('value')} {item.get('unit')} (基準値: {item.get('reference')})"

            if status in ['正常', 'normal']:
                normal_items.append(item_text)
            elif status in ['注意', 'caution', '要注意']:
                attention_items.append(item_text)
            else:
                abnormal_items.append(item_text)

        # 異常値を優先表示
        if abnormal_items:
            context_parts.append("\n【要注意】以下の項目が異常値です：")
            context_parts.extend(abnormal_items)

        if attention_items:
            context_parts.append("\n【注意】以下の項目が基準値外です：")
            context_parts.extend(attention_items)

        if normal_items:
            context_parts.append(f"\n【正常範囲】{len(normal_items)}項目が正常範囲内")

    # 利用可能な遺伝子カテゴリー
    if available_gene_categories:
        context_parts.append("\n\n【利用可能な遺伝子データカテゴリー】")
        context_parts.append("以下のカテゴリーの遺伝子情報を要求できます：")
        for category in available_gene_categories:
            context_parts.append(f"- {category}")
        context_parts.append("\n必要に応じて「🧬 [カテゴリー名]に関する遺伝子情報」の形式で要求してください。")

    return "\n".join(context_parts)


def build_gene_data_context(gene_data: Dict) -> str:
    """遺伝子データのコンテキスト"""
    context_parts = ["【ユーザーの遺伝子データ】"]

    for category, markers in gene_data.items():
        context_parts.append(f"\n■ {category}")

        for marker in markers:
            title = marker.get('title', '')
            genotypes = marker.get('genotypes', {})
            impact = marker.get('impact', {})

            context_parts.append(f"  - {title}")

            # 遺伝子型を表示
            for snp_id, genotype in genotypes.items():
                context_parts.append(f"    {snp_id}: {genotype}")

            # 影響スコアがある場合は表示
            if impact:
                protective = impact.get('protective', 0)
                risk = impact.get('risk', 0)
                neutral = impact.get('neutral', 0)
                score = impact.get('score', 0)

                context_parts.append(f"    影響: 保護{protective}/リスク{risk}/中立{neutral} (スコア: {score:+d})")

    return "\n".join(context_parts)


def call_openai(messages: List[Dict]) -> str:
    """OpenAI APIを呼び出し"""
    try:
        print(f"🤖 Calling OpenAI API with {len(messages)} messages")

        # メッセージのトークン数を概算（デバッグ用）
        total_chars = sum(len(msg.get('content', '')) for msg in messages)
        estimated_tokens = total_chars // 4
        print(f"📊 Estimated tokens: ~{estimated_tokens}")

        response = openai.ChatCompletion.create(
            model="gpt-4o-mini",
            messages=messages,
            temperature=0.7,  # よりフレンドリーな応答のため0.4→0.7に変更
            max_tokens=1500,  # より詳細な応答のため1000→1500に変更
            top_p=1.0,
            frequency_penalty=0.0,
            presence_penalty=0.0
        )

        assistant_message = response.choices[0].message.content

        # 使用トークン数をログ出力
        usage = response.get('usage', {})
        print(f"📊 Token usage: prompt={usage.get('prompt_tokens')}, completion={usage.get('completion_tokens')}, total={usage.get('total_tokens')}")

        return assistant_message

    except Exception as e:
        print(f"❌ OpenAI API error: {str(e)}")
        raise


def cors_headers():
    """CORS ヘッダー"""
    return {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type,Authorization',
        'Access-Control-Allow-Methods': 'OPTIONS,POST,GET'
    }
