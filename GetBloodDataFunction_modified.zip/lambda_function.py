import json
import boto3
from decimal import Decimal

# DynamoDBクライアント
dynamodb = boto3.resource('dynamodb')
blood_table = dynamodb.Table('blood-results')

# Decimal型をfloatに変換するヘルパー関数
def decimal_to_float(obj):
    if isinstance(obj, Decimal):
        return float(obj)
    elif isinstance(obj, list):
        return [decimal_to_float(item) for item in obj]
    elif isinstance(obj, dict):
        return {key: decimal_to_float(value) for key, value in obj.items()}
    return obj

def lambda_handler(event, context):
    """
    ユーザーの血液検査情報を返すAPI
    """
    print(f"Event: {json.dumps(event)}")
    
    try:
        # パスパラメータまたはクエリパラメータからuserIdを取得
        user_id = None
        
        # パスパラメータから取得
        if event.get('pathParameters'):
            user_id = event['pathParameters'].get('userId')
        
        # クエリパラメータから取得
        if not user_id and event.get('queryStringParameters'):
            user_id = event['queryStringParameters'].get('userId')
        
        # ボディから取得
        if not user_id and event.get('body'):
            body = json.loads(event['body'])
            user_id = body.get('userId')
        
        if not user_id:
            return {
                'statusCode': 400,
                'headers': {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                'body': json.dumps({
                    'error': 'userIdが必要です'
                })
            }
        
        # DynamoDBから血液検査データを取得（全履歴）
        response = blood_table.query(
            KeyConditionExpression='userId = :userId',
            ExpressionAttributeValues={
                ':userId': user_id
            },
            ScanIndexForward=False  # 最新のデータが先頭（降順）
        )

        if response['Items']:
            # 全ての履歴データをDecimal→floatに変換
            history_data = [decimal_to_float(item) for item in response['Items']]

            return {
                'statusCode': 200,
                'headers': {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                'body': json.dumps({
                    'success': True,
                    'data': {
                        'history': history_data
                    }
                })
            }
        else:
            return {
                'statusCode': 404,
                'headers': {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                'body': json.dumps({
                    'success': False,
                    'message': '血液検査データが見つかりません'
                })
            }
        
    except Exception as e:
        print(f"Error: {str(e)}")
        return {
            'statusCode': 500,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps({
                'success': False,
                'error': str(e)
            })
        }